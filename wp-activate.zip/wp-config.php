<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'tithi_plugin');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Oc 2_`m/Wh${6y,lK(H|^34BTY:$b2~3n)~8cva_FCwk,>y<q}dJ!(cnOA6l&+a~');
define('SECURE_AUTH_KEY',  'R:H=4dwVW [S{sU?9B{*81N[@:)dNCN_|^/g3k*Jfhd![(#m,CZ<u37;E*}z*v(p');
define('LOGGED_IN_KEY',    'Te>I<u+%Z#z N`1GV1TG,L[<*N&nsSgB75JNEq>3 *R_IRSE;#z0q^cxqepCpvqo');
define('NONCE_KEY',        'SAy<V )O^6VAy$YDhN&]w{B}STN[JPla=_G=!i%jm;sc%=.9L/<IHv0yBPE.YKFU');
define('AUTH_SALT',        '*)/Zw_5c`^I5E.`0 -^~:Fs-AiSZ$2urjAvwzTXyjEc!fE$9iPI8Vdtdi83T-JaT');
define('SECURE_AUTH_SALT', 'Kml4UTU+VB{TN##+04d]RA P[mJ#[u~+sjc],}3SV{CN0N_YE,q#peWMh|dm A$O');
define('LOGGED_IN_SALT',   'yTBJ@cJPx8{zk :9bt?CJ)7VskMaA-PPy $DkD%OU#U^0{M!s|ScWz)- ?1-|&q ');
define('NONCE_SALT',       'Nt~)Ip}MO*9uy*<[_S3zW-;b<9=_O&;HWE<Ly[L3!rw`h#$+$=oh@GuH2aIR.@mP');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
